﻿function lianjie(type) {
    switch (type) {
        case "bar":
            window.location.href = "lib/导入模板.rar";
            break;

    }
}