﻿$(function () {
    $(document).keydown(function (e) {
        if (e.keyCode == 8 || e.keyCode == 13) {
            return false;
        }
    }); 

});