﻿function isCheckIP(ip) {
    var strs = ip.split(",");
    var istrue = true;
    for (var i = 0; i < strs.length; i++) {
        if (strs[i].length == 0) {
            break;
        }
        if (strs[i].indexOf("*") > 0) {
            var a = strs[i].replace("*", "10");
            if (isValidIP(a) == true) {
                //                newip += strs[i] + ",";
                istrue = true;
            } else {
                istrue = false;
                break;
            }
        } else if (strs[i].indexOf("-") > 0) {
            var b = strs[i].split("-");
            if (b.length > 1) {
                if (isValidIP(b[0]) == true) {
                    istrue = true;
                } else {
                    istrue = false;
                    break;
                }
                if (isValidIP(b[1]) == true) {
                    istrue = true;
                } else {
                    istrue = false;
                    break;
                }
            } else {
                istrue = false;
                break;
            }
        } else {
            if (isValidIP(strs[i]) == true) {
                //                newip += strs[i] + ",";
                istrue = true;
            } else {
                istrue = false;
                break;
            }
        }
    }

    return istrue;
}


function isValidIP(ip) {
    var reg = /(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)/;
    return reg.test(ip);
}