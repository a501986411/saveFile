create table user_msg(id INT NOT NULL AUTO_INCREMENT,user_id int(11) NOT NULL,total_num int(11) NOT NULL,send_num int(11) NOT NULL,PRIMARY KEY ( id ));
INSERT INTO user_msg (user_id,total_num,send_num) VALUES(100,10000,1000); 
create table send_msg_log(
id INT NOT NULL AUTO_INCREMENT,
user_id int(11) NOT NULL,
task_id int(11) NOT NULL,
content varchar(500) NOT NULL,
tel_num int(11) NOT NULL,
tel_type varchar(60) NOT NULL,
send_num int(11) NOT NULL,
send_status varchar(30) not null,
send_ip varchar(40) not null,
send_time varchar(40) not null,
status_detail varchar(255) not null,
PRIMARY KEY ( id ));