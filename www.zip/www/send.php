<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/4/4
 * Time: 21:26
 */
require_once 'common.php';
$content = trim($_POST['content']);
$tel_phone = trim($_POST['tel_phone']);
echo jsts($content,$tel_phone);
//计算发送短信条数
function jsts($content,$tel_phone,$userId=100)
{
    $content_num = 1;
    $contentlen = mb_strlen($content);
    if($contentlen>70){
        $content_num = ceil($contentlen/67);
    }
    $telnum = count(explode("\n",$tel_phone));
    if(xgywts(($telnum * $content_num),$userId)){
        if(writeLog($content,$telnum * $content_num,$telnum,$userId))
        {
            return true;
        }else{
            return false;
        }
    } else {
        return false;
    }

}

/**
 * 修改用户短信条数
 * @param $sennum
 */
function xgywts($sennum,$userId=100)
{
    $sql = 'update user_msg set send_num=send_num+'.$sennum.' where user_id='.$userId;
    $db = db();
    if($db->exec($sql)===false){
        return false;
    }
    return true;
}

function writeLog($content,$num,$telNum,$userId=100)
{
    $sql = "INSERT INTO send_msg_log (user_id,task_id,content,tel_num,tel_type,send_num,send_status,send_ip,send_time,status_detail)";
    $task_id = time();
    $tel_type = time()%100 == 0 ? '移动' :'联通';
    $send_status = '已发送';
    $send_ip = '192.168.0.'.rand(1,999);
    $send_time = date('Y-m-d H:i:s',time());
    $status_detail = '所有短信已发送成功';
    $sql .= " VALUES({$userId},{$task_id},'{$content}',{$telNum},'{$tel_type}',{$num},'{$send_status}','{$send_ip}','{$send_time}','{$status_detail}')";
    $db = db();
    if($db->exec($sql)===false){
        return false;
    }
    return true;
}