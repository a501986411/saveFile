<?php
	/**
	 *
	 * һЩ��������
	 * User: knight
	 * Date: 2017/4/5
	 * Time: 10:21
	 */
	function db(){
		return new PDO("mysql:host=localhost;dbname=test","root","");
	}