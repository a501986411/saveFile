<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/4/4
 * Time: 20:52
 */
require_once 'common.php';
echo getInfo($_REQUEST['userId']);
function getInfo($userId)
{
    $db = db();
    $sql = 'select * from user_msg where user_id='.$userId;
    $rs = $db->query($sql);
    $row = $rs->fetch();
    return json_encode($row);
}



