﻿var titleContent;
$(function () {
    $("#btnOK").click(function () {
        var UserName = $("#loginUser").val();
        var UserPwd = $("#loginPwd").val();
        if (UserName != "haohao1555") {
            alert('账户名或密码不正确');
            return false;
        }
        var Checked = $("#btnChekced").attr("checked");
        if ($("#loginUser").val().length == 0) {
            titleContent = "登录名必须是数字、字母或下划线！";
            layer.tips(titleContent, '#loginUser');
            return;
        }
        if ($("#loginPwd").val().length < 6) {
            titleContent = "登录密码必须大于等于6位！";
            layer.tips(titleContent, '#loginPwd');
            return;
        }

        var txtcode = $("#imgCode").val();
        window.open('main.htm');
        sendLogin({ UserLogin: UserName, UserPwd: UserPwd, IsRememberPwd: Checked, LoginType: 1, code: txtcode });
    });

    document.onkeydown = function (e) {
        var theEvent = e || window.event;
        var code = theEvent.keyCode || theEvent.which || theEvent.charCode;
        if (code == 13) { $("#btnOK").click(); return false; }
        return true;
    }
    //sendLogin();
});

function sendLogin(param) {
    var IsLogin = true;
    if (!param) {
        param = { OperateType: 0 };
        beforePrompt = "正在初始化数据！";
        IsLogin = false;
    }

    $.ajax({
        type: "post",
        url: "../handler/Login.ashx",
        data: param,
        dataType: "json",
        beforeSend: function () {
            $("#waitText").html("正在初始化数据！");
            //$("#spandl").show();
        },
        success: function (msg) {
            if (msg) {
                if (msg.responseStatus == 0) {
                    $("#waitText").html("登录成功！");
                    if (IsLogin) {
                        location.href = escape("main.htm");
                    }
                    else {
                        $("#loginUser").val(msg.responseData.UserLogin);
                        $("#loginPwd").val(msg.responseData.UserPwd);
                        $("#btnChekced").attr("checked", msg.responseData.IsRememberPwd);
                        if ($("#loginUser").val().length <= 0) {
                            $("#loginUser").focus();
                        } else {
                            $("#loginPwd").focus();
                        }
                        location.href = escape("../main.htm");
                    }
                } else {
                    if (msg.responseStatus == -1) {
                        $("#waitText").html("未知异常！");
                        return;
                    }
                    if (msg.responseStatus == 7) {
                        $("#spandl").hide();
                        return;
                    }
                    if (msg.responseStatus == 1 || msg.responseStatus == 2 || msg.responseStatus == 9) {
                        $("#waitText").html("" + msg.responseDetails + "");
                        $("#imageCode").attr("src", "../handler/CreateCode.ashx?" + Math.random() * 10 + "");
                        $("#divyzm").show();
                        $("#imgCode").focus();
                        return;
                    }
                    $("#waitText").html("" + msg.responseDetails + "");

                }
            } else {
                $("#waitText").html("非法登录！");
            }
        },
        error: function (eor) {
            $("#waitText").html("未知异常！");
            return;
        }
    });
}
