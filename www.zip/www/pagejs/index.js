﻿$(function () {
    var mydate = new Date();
    $.ajax({
        type: "post",
        url: "handler/mainService.ashx?type=tjjl",
        dataType: "text",
        success: function (data) {
            if (data) {
                var strs = data.split("$");
                if (strs.length > 0) {
                    $("#syts").text(strs[0]);
                    $("#czts").text(strs[1]);
                    $("#fsts").text(-(strs[2]));
                    $("#fssbts").text(strs[3]);
                }
            }
        },
        error: function (eor) {
            return;
        }
    });


    $(".suspend").mouseover(function () {
        $(this).stop();
        $(this).animate({ width: 160 }, 400);
    });
    $(".suspend").mouseout(function () {
        $(this).stop();
        $(this).animate({ width: 40 }, 400);
    });



});

function onshow(ids) {
    if (ids.length > 0) {
        ids = ids.replace("kbnuw","");
        $("#txtcs").val(ids);
        layer.open({
            type: 2,
            title: '通知公告',
            area: ['580px', '520px'],
            fix: false,
            maxmin: false,
            content: 'pageinfo_GONGGAO.htm' 

        });
    }
}