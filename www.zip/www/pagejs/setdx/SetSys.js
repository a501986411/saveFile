﻿$(function () {
    var aindex;
    //加载数据
    loaduser();
    loadsetinfo();

    /***********账户管理***********************/

    $("#btnOKzhgl").click(function () {
        var phone = $.trim($("#txtphone").val());
        var name = $.trim($("#txtlxr").val());
        var gsmc = $.trim($("#txtgsmc").val());
        if (checkPhone(phone) == false) {
            layer.msg('紧急联系人手机号码格式错误！', { icon: 7 });
            return;
        }

        //修改
        $.ajax({
            type: "post",
            url: "handler/SetUserInfo.ashx?OpareType=updateuser",
            data: { PHONE: phone, REALNAME: name, GSMC: gsmc },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "ok") {
                    layer.msg('修改成功！', { icon: 1 });
                    return;
                } else {
                    layer.msg('修改失败！', { icon: 7 });
                    return;
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
                return;
            }
        });
    });

    /***********密码管理***********************/

    $("#btnpwdok").click(function () {

        var ypwd = $("#txtpwd").val();
        var npwd = $("#txtnewpwd").val();
        var cnpwd = $("#txtcnewpwd").val();

        if (ypwd.length == 0) {
            layer.msg('请输入原密码！', { icon: 7 });
            return;
        }

        if (npwd.length == 0) {
            layer.msg('请输入新密码！', { icon: 7 });
            return;
        }

        if (npwd.length < 6) {
            layer.msg('密码长度必须不小于6位！', { icon: 7 });
            return;
        }

        if (cnpwd.length == 0) {
            layer.msg('请输入确定新密码！', { icon: 7 });
            return;
        }

        if (npwd != cnpwd) {
            layer.msg('确定密码不一致！', { icon: 7 });
            return;
        }

        debugger;
        $.ajax({
            type: "post",
            url: "handler/SetUserInfo.ashx?OpareType=updatepwd",
            data: { ymima: ypwd, xmima: npwd },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "ok") {
                    window.parent.layer.confirm('重置密码成功！', {
                        btn: ['退出重新登录'], closeBtn: 0
                    }, function () {
                        window.parent.location.href = "../../login.htm";
                    });
                } else if (data == "ycw") {
                    layer.msg('原密码错误！', { icon: 7 });
                    return;
                } else {
                    layer.msg('重置密码失败！', { icon: 7 });
                    return;
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
            }
        });
    });

    /***********余额提醒***********************/

    $("#issettx").click(function () {
        if ($('#issettx').hasClass("checked")) {
            $('#issettx').removeClass('checked');
        } else {
            $('#issettx').addClass('checked');
        }
    });

    $("#btntxok").click(function () {
        var tsye = $("#txtsetye").val();
        var phone1 = $("#txtphone1").val();
        var phone2 = $("#txtphone2").val();

        var isendtx = 0;
        if ($('#issettx').hasClass("checked")) {
            isendtx = 1;
        }

        if (tsye.length == 0 || tsye < 20) {
            layer.msg('剩余条数设置必须>20条！', { icon: 7 });
            $("#txtsetye").focus();
            return;
        }

        if (phone1.length == 0 && phone2.length == 0) {
            layer.msg('最少绑定一个提醒手机号码！', { icon: 7 });
            $("#txtphone1").focus();
            return;
        }

        if (phone1.length > 0) {
            if (checkPhone(phone1) == false) {
                layer.msg('手机号码格式错误！', { icon: 7 });
                $("#txtphone1").focus();
                return;
            }
        }

        if (phone2.length > 0) {
            if (checkPhone(phone2) == false) {
                layer.msg('手机号码格式错误！', { icon: 7 });
                $("#txtphone2").focus();
                return;
            }
        }

        $.ajax({
            type: "post",
            url: "handler/SetUserInfo.ashx?OpareType=setyetx",
            data: { TXTS: tsye, CPHONE1: phone1, CPHONE2: phone2, ISSYTX: isendtx },
            dataType: "text",
            success: function (data) {
                if (data == "ok") {
                    layer.msg('设置成功！', { icon: 1 });
                } else {
                    layer.msg('设置失败！', { icon: 7 });
                }
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
            }
        });
    });

    /***********IP限制***********************/

    $("#issetip").click(function () {
        if ($('#issetip').hasClass("checked")) {
            $('#issetip').removeClass('checked');
        } else {
            $('#issetip').addClass('checked');
        }
    });

    $("#btnipok").click(function () {
        var ips = $("#txtIPS").val();
        var newip = "";
        if (ips.length > 0) {
            var ipArray = $("#txtIPS").text().split(",");
            ipArray = ipArray.del();
            var newip = ipArray.join(',');
            $("#txtIPS").val(newip);

            if (newip.length > 0) {
                if (isCheckIP(newip) == false) {
                    layer.msg("IP存在格式错误！", { icon: 7 });
                    return;
                }
            }
        }

        var issetip = 0;
        if ($('#issetip').hasClass("checked")) {
            issetip = 1;
        }

        $.post("handler/SetUserInfo.ashx?OpareType=updateip", { XZIP: newip, ISQDIP: issetip },
        function (data) {
            if (data == "ok") {
                layer.msg('设置成功！', { icon: 1 });
            } else {
                layer.msg('设置失败！', { icon: 5 });
            }
        });
    });

    $("#txtIPS").keydown(function () {
        var e = $(this).event || window.event;
        var code = parseInt(e.keyCode);
        if (code == 13) {
            var ips = $("#txtIPS").val();
            if (ips.length > 0) {
                var ipArray = ips.split(",");
                ipArray = ipArray.del();
                var newip = ipArray.join(',');
                $("#txtIPS").val(newip);
                if (newip.length > 0) {
                    if (isCheckIP(newip) == false) {
                        layer.msg("IP存在格式错误！", { icon: 7 });
                        return;
                    }
                }
            }
        }
    });

    /***********推送地址设置***********************/

    $("#sxbg").click(function () {
        if ($('#sxbg').hasClass("checked")) {
            $('#sxbg').removeClass('checked');
        } else {
            $('#sxbg').addClass('checked');
        }
    });

    $("#btntsbgok").click(function () {
        var sxdz = $("#txtSXDZ").val();
        var xxdz = $("#txtXXDZ").val();
        isqdts = 0;
        if ($('#sxbg').hasClass("checked")) {
            isqdts = 1;
        }

        $.ajax({
            type: "post",
            url: "handler/SetUserInfo.ashx?OpareType=updatetxdz",
            data: { SXDZ: sxdz, XXDZ: xxdz, ISTSBG: isqdts },
            dataType: "text",
            success: function (data) {
                if (data == "ok") {
                    layer.msg('设置成功！', { icon: 1 });
                } else {
                    layer.msg('设置失败！', { icon: 7 });
                }
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
            }
        });
    });

});

function loadsetinfo() {
    $.ajax({
        type: "post",
        url: "handler/SetUserInfo.ashx?OpareType=selectset",
        dataType: "json",
        success: function (data) {
            if (data.length>0) {
                $("#txtsetye").val(data[0].ZHYE);
                $("#txtphone1").val(data[0].PHONE1);
                $("#txtphone2").val(data[0].PHONE2);
                var isdxtx = data[0].ISSYTX;
                if (isdxtx == true) {
                    if (!$('#issettx').hasClass("checked")) {
                        $('#issettx').addClass('checked');
                    }
                }

                $("#txtIPS").val(data[0].XZIP)

                var isxzip = data[0].ISGDIP;
                if (isxzip == true) {
                    if (!$('#issetip').hasClass("checked")) {
                        $('#issetip').addClass('checked');
                    }
                }

                $("#txtSXDZ").val(data[0].SXDZ);
                $("#txtXXDZ").val(data[0].XXDZ);

                var issx = data[0].ISTSBG;
                if (issx == true) {
                    if (!$('#sxbg').hasClass("checked")) {
                        $('#sxbg').addClass('checked');
                    }
                }
            }
        },
        error: function (eor) {
            layer.msg('加载数据异常！', { icon: 5 });
        }
    });
}

function loaduser() {
    $.ajax({
        type: "post",
        url: "handler/SetUserInfo.ashx?OpareType=select",
        dataType: "text",
        success: function (data) {
            if (data) {
                var strs = data.split("$");
                if (strs.length > 0) {
                    if (strs[0].length > 0) {
                        $("#txtgsmc").val(strs[0]);
                    }
                    if (strs[1].length > 0) {
                        $("#txtlxr").val(strs[1]);
                    }

                    if (strs[2].length > 0) {
                        $("#txtphone").val(strs[2]);
                    }
                }
            }
        },
        error: function (eor) {
            layer.msg('加载数据异常！', { icon: 5 });
        }
    });
}

function checkPhone(phone) {
    var re = /^1[3,4,5,6,7,8]\d{9}$/;
    if (re.test(phone)) {
        return true;
    } else {
        return false;
    }
}

function checkRate(input) {
    var re = /^[1-9]+[0-9]*]*$/;
    if (!re.test(input.value)) {
        input.value = "";
        input.focus();
        return false;
    }
    if (input.value < 21) {
        input.focus();
        layer.tips('提醒条数必须大于20条', '提示', {
            tips: [1, '#3595CC'],
            time: 4000
        });
        return false;
    }
}

Array.prototype.del = function () {
    var a = {}, c = [], l = this.length;
    for (var i = 0; i < l; i++) {
        var b = this[i];
        var d = (typeof b) + b;
        if (a[d] === undefined) {
            c.push(b);
            a[d] = 1;
        }
    }
    return c;
}

