﻿$(function () {
    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth, width: window.parent.maiWidth });
    });
    var aindex;
    $('#tt').datagrid({
        url: "handler/DXMBService.ashx?OpareType=mobanselect",
        height: window.parent.maiHeigth,
        width: window.parent.maiWidth,
        nowrap: false,
        autoRowHeight: true,
        striped: false,
        collapsible: false,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50, 150, 300],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { checkbox: 'true', width: 50 },
                    { field: 'ID', hidden: true },
                    { field: 'QMMC', hidden: true },
                    { field: 'DXNR', title: '短信内容', width: 400, align: 'center' },
                    { field: 'LRSJ', title: '添加时间', width: 120, align: 'center' }
				]]
    });

    /********************常用短信******************/
    $("#btnADD").click(function () {
        layer.open({
            type: 2,
            title: '添加模板',
            area: ['450px', '450px'],
            fix: false, //不固定
            maxmin: false,
            content: 'template_add.htm'

        });
    });

    $("#btnDel").click(function () {
        var param = "";
        var rowsr = $("#tt").datagrid("getSelected");
        if (!rowsr) {
            layer.msg('未选中删除项！', { icon: 7 });
            return;
        }
        if (rowsr.length == 0) {
            return;
        }

        $.ajax({
            type: "post",
            url: "handler/DXMBService.ashx?OpareType=delemb",
            data: { delid: rowsr.ID },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
                var index = $('#tt').datagrid('getRowIndex', rowsr);
                $('#tt').datagrid('deleteRow', index);
            },
            success: function (data) {
                if (data == "ok") {
                    $('#tt').datagrid('reload');
                } else {
                    layer.msg('删除失败！', { icon: 7 });
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('删除失败！', { icon: 5 });
                return;
            }
        });
    });

    $("#btnSearch").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
       
        var cdxnr = $("#txtmbnr").val();
        if (cdxnr.length > 0) {
            param.push({ cmbnr: cdxnr });
        }
        $('#tt').datagrid('load', param);
    });

});
 