﻿var maiHeigth = 0;
var maiWidth = 0;
$(function () {

    $(window).resize(myfunction);
    myfunction();
});

//定义一个方法:这个方法控制浏览器页面背景色的切换变化
function myfunction() {

    var bodyheight = $(document).height();
    var bodywidth = $(document).width();
    if (bodyheight > 760) {
        maiHeigth = bodyheight - 163;
    } else {
        maiHeigth = bodyheight - 163;
    }

    if (bodywidth > 1024) {
        maiWidth = bodywidth - 240;
    } else {
        maiWidth = bodywidth;
    }
}