function openSubNavClick(j) {
    for (var i = 0; i < 6; i++) {
        var s = '.hasSub' + i;
        if ($(s).length > 0) {
            var t = $(s).find('.toggle-icon');
            var subShow = $(s).hasClass('active');

            if (subShow) {
                $(t).removeClass('active');
                $(s).removeClass('active');
                $(s).parent().find('.sub-nav').removeClass('active');
            }
        }
    }
    var s = '.hasSub' + j;
    if ($(s).length > 0) {
        var t = $(s).find('.toggle-icon');
        var subShow = $(s).hasClass('active');
        if (subShow) {
            $(t).removeClass('active');
            $(s).removeClass('active');
            $(s).parent().find('.sub-nav').removeClass('active');
        } else {
            $(t).addClass('active');
            $(s).addClass('active');
            $(s).parent().find('.sub-nav').addClass('active');
        }
    }
}

$(function () {
    $.ajax({
        type: "post",
        url: "handler/mainService.ashx?type=ckdl",
        dataType: "text",
        success: function (data) {
            if (data == "no") {
                $("#dlcd").css("display", "none");
            }
        },
        error: function (eor) {
            return;
        }
    });

    $.ajax({
        type: "post",
        url: "handler/mainService.ashx?type=ckhy",
        dataType: "text",
        success: function (data) {
            if (data == "ok") {
                $("#txtapi").css("display", "block");
            }
        },
        error: function (eor) {
            return;
        }
    });

    $(".topmenu-div").hover(function () {
        var self = $(this);
        var topmenuBtn = self.find(".topmenu-btn");

        self.find('.topmenu').show();
        $(topmenuBtn).css({
            "margin-top": "7px",
            "transform": "rotate(45deg)",
            "-ms-transform": "rotate(45deg)",
            "-moz-transform": "rotate(45deg)",
            "-webkit-transform": "rotate(45deg)",
            "-o-transform": "rotate(45deg)"
        });
    }, function () {
        var self = $(this);
        self.find('.topmenu-btn').css({
            "margin-top": "0",
            "transform": "rotate(225deg)",
            "-ms-transform": "rotate(225deg)",
            "-moz-transform": "rotate(225deg)",
            "-webkit-transform": "rotate(225deg)",
            "-o-transform": "rotate(225deg)"
        });
        self.find('.topmenu').hide();
    });
    $("#loginout").click(function () {
        layer.confirm('是否要退出系统？', {
            btn: ['确定', '取消'] //按钮
        }, function () {
            $.post("handler/Login.ashx", { LoginType: -1 }, function (data) {
                if (data) {
                    if (data.responseStatus == 8) {
                        window.location = "../login.htm";
                    }
                }
            }, "json");
        }, function () {
            layer.msg('欢迎您的归来！', '#userinfo', {
                time: 3000 //20s后自动关闭
            });
        });
    });
});


$(document).keydown(function (e) {
    if (e.keyCode == 8) {
        return false;
    }
});
 