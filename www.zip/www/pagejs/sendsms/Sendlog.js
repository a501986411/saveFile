﻿$(function () {
    $('#cmblb').combo({
        panelHeight: 80,
        editable: false
    });

    $('#tt').datagrid({
         url: "handler/MsgService.php?userId=100",
        height: window.parent.maiHeigth,
        width: window.parent.maiWidth,
        nowrap: false,
        autoRowHeight: false,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50, 100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'ID', hidden: true },
                    { field: 'USERID', hidden: true },
                    { field: 'TASKID', title: '任务ID', width: 130, align: 'center' },
                    { field: 'LBMC', title: '网关类别', width: 100, align: 'center' },
                    { field: 'DXNR', title: '短信内容', width: 250, align: 'center' },
                    { field: 'JSHM', hidden: true },
                    { field: 'HMGS', title: '号码个数', width: 80, align: 'center' },
                    { field: 'HMFL', title: '号码分类', width: 100, align: 'center' },
                    { field: 'FSTS', title: '发送条数', width: 80, align: 'center' },
                    { field: 'FSZT', title: '发送状态', width: 80, align: 'center'},
                    { field: 'FSIP', title: '发送IP', width: 100, align: 'center' },
                    { field: 'FSSJ', title: '发送时间', width: 100, align: 'center'},
                    { field: 'opare', title: '状态详情', width: 140, align: 'center',
                        formatter: function (value, row) {
                            if (row.FSZT == '已发送') {
                                var e = "<a href=\"javascript:void(0);\" onclick=\"dowhms('" + row.ID + "')\">下载号码</a>&nbsp;&nbsp;&nbsp;";
                                e += "<a href=\"javascript:void(0);\" onclick=\"showlist('" + row.ID + "')\">状态详情</a>&nbsp;";
                            } else {
                                var e = "<a href=\"javascript:void(0);\" onclick=\"dowhms('" + row.ID + "')\">下载号码</a>&nbsp;&nbsp;&nbsp;";
                            }
                            e += "<a href=\"javascript:void(0);\" id=\"deleteLog\" onclick='deleteLog("+row.ID+")'>删除</a>&nbsp;";
                            console.log(e);
                            return e;
                        }
                    }
				]]

    });
    $("#btnSearch").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        var dxlb = $('#cmbdxlb').combobox('getValue');
        var kssj = $("#txtKSSJ").val();
        var jssj = $("#txtJSSJ").val();
        var cdxnr = $("#txtdxnr").val();
        if (kssj.length > 0 && jssj.length > 0 && kssj <= jssj) {
            param.push({ KSSJ: kssj });
            param.push({ JSSJ: jssj });
        }

        if (cdxnr.length > 0) {
            param.push({ DXNR: cdxnr });
        }

        if (dxlb.length > 0) {
            param.push({ FSZT: dxlb });
        }
        $('#tt').datagrid('load', param);
    });

    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth, width: window.parent.maiWidth });
    });
});

function dowhms(id) {
    if (id) {
        $('body').append("<iframe id=\"downloadcsv\" style=\"display:none\"></iframe>");
        $('#downloadcsv').attr('src', "handler/DownService.ashx?OpareType=downHM&&MSGID=" + encodeURI(id) + "");
    }
}

function showlist(rowid) {
    if (rowid) {
        window.location.href = "../../pageinfo/passage/SMSReport.aspx?cothid=" + encodeURI(rowid) + "&r=" + Date.parse(new Date()) + "";
    }
}
 


