﻿$(function () {
    var aindex;
    /***********************页面初始化*******************************/
    $('#cmbdxlb').combobox({
        url: "handler/SendSMS.ashx?OpareType=selectdxlb",
        valueField: 'ID',
        textField: 'LBMC'
    });

    $("#btnclear").click(function () {
        $("#txtdxlist").val("");
        $("#spanPhoneLength").html("0");
    });

    //导入Excel布局
    $("#btndrexcel").click(function () {
        
        layer.open({
            type: 2,
            title: '配置EXCEL',
            shadeClose: false,
            shade: 0.2,
            area: ['440px', '470px'],
            content: 'sendsms_other_d2d2.htm'
        });
    });

    //执行发送
    $("#btnsend").click(function () {
        var dxlbmc = $('#cmbdxlb').combobox('getText');
        var dxlb = $('#cmbdxlb').combobox('getValue');
        var msg = $("#txtdxlist").val();
        var dstime = $('#txtdssj').val();

        if (dxlb.length == 0) {
            layer.msg('请选择网关类别！', { icon: 7 });
            return;
        }
		
		/*
        if (dxlbmc.indexOf("106") < 0) {
            layer.msg('您的类别不可使用，只有106类别的网关可以使用', { icon: 7 });
            return;
        }

        if (msg.length == 0) {
            layer.msg('内容不能为空！', { icon: 7 });
            return;
        }
		*/

        if (dxlb.indexOf("106") >= 0 && dxlbmc.indexOf("营销") >= 0) {
            var strs = msg.split("$$");
            if (strs.length > 0) {
                var msg = strs[0];
                if (msg.indexOf("退订回") < 0) {
                    layer.msg('营销短信必须加退订回T！', { icon: 7 });
                    return;
                }
            }
        }

		alert( '发送成功！' );

        $.ajax({
            type: "post",
            url: "handler/D2DService.ashx?OpareType=send",
            data: { dxid: dxlb, dssj: dstime, dxmsg: escape(clmsg(msg)) },
            dataType: 'text',
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
                $("#btnsend").attr({ "disabled": "disabled" });
                $("#btnsend").text("正在发送中....");
            },
            success: function (data) {
                if (data.indexOf("发送成功") >= 0) {
                    $('#cmbdxlb').combobox('reload');
                    $("#txtdxlist").val("");
                    $("#spanPhoneLength").html("0");
                }
                $("#btnsend").removeAttr("disabled");
                $("#btnsend").text("确定发送");
                layer.msg(data, { icon: 1 });
                return;
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg("发送异常，请重新发送", { icon: 5 });
                return;
            }
        });
    });


    /***************************改变分辨率**************************/

    $(window).resize(changeifrma);
    changeifrma();
});

function changeifrma() {
    var ggg = $(window).height();
    if (ggg < 500) {
        $("#txtdxlist").height(340);
    } else {
        $("#txtdxlist").height(ggg - 240);
    }
}

//保存内容
function clmsg(msg) {
    msg = msg.replace("+", "$加号$");
    msg = msg.replace("!", "！");
    msg = msg.replace("=", "$等于$");
    msg = msg.replace("'", "");
    return msg;
}

 
