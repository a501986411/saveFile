﻿$(function () {
    /********************页面初始化******************/
    var aindex;

    $("#cmbdxlb").keydown(function (e) {
        if (e.keyCode == 8 || e.keyCode == 13) {
            return false;
        }
    });

    $('#cmbdxlb').combobox({
        url: "handler/SendSMS.ashx?OpareType=selectdxlb",
        valueField: 'ID',
        textField: 'LBMC',
        onSelect: function (data) {
            var dxlx = data.DXLX;
            if (dxlx == "106营销") {
                $("#tdht").css("display", "block");
            } else {
                $("#tdht").css("display", "none");
            }
            ContentChange();
        }
    });

    /********************检测屏蔽词****************/

    $("#btnjcpbc").click(function () {
        checkkeyword();
    });

    /************************短信字符计算*******************/
    $("#txtMsgContent").keyup(function () {
        ContentChange();
    });

    $("#txtQM").keyup(function () {
        ContentChange();
    });

    /**************************手机号码计数*******************************/

    $("#txtphone").keydown(function () {
        var e = $(this).event || window.event;
        var code = parseInt(e.keyCode);
        if (code == 8) {
            PhoneChange();
        }
        return true;
    });

    $("#txtphone").keypress(function () {
        var e = $(this).event || window.event;
        var code = parseInt(e.keyCode);
        if (code == 13) {
            var re = /^1[3,4,5,6,7,8]\d{9}$/;
            var phones = $.trim($(this).val()).split("\n")
            var curph = phones[phones.length - 1];
            if (curph.length == 0) {
                PhoneChange();
                return true;
            } else {
                if (re.test(phones[phones.length - 1])) {
                    PhoneChange();
                    return true;
                } else {
                    layer.msg('号码格式错误，一行一个号码回车换行！', { icon: 7 });
                    return false;
                }
            }
        }
    });

    $("#txtphone").focus(function () {
        if ($(this).val().indexOf('回车') >= 0) {
            $(this).val('');
            return;
        }
    });

    $("#txtphone").blur(function () {
        PhoneChange();
    });


    /****************************文件txt导入***************************/
    $("#btninputtxt").click(function () {
        layer.open({
            type: 2,
            title: '导入操作',
            area: ['350px', '340px'],
            fix: false, //不固定
            maxmin: false,
            content: '/sendsms/other/txt'
        });
    });

    /****************************通信录导入****************************/
    $("#btninputtxl").click(function () {
        layer.open({
            type: 2,
            title: '导入操作',
            area: ['360px', '420px'],
            fix: false, //不固定
            maxmin: false,
            content: '/sendsms/other/book'
        });
    });

    /****************************去重重复****************************/
    $("#btnqccf").click(function () {
        qchongfu();
    });

    /****************************错号排除****************************/
    $("#btnchpc").click(function () {
        chpc();
    });

    /****************************三网区分****************************/
    $("#btnswqf").click(function () {
        var phones = $.trim($("#txtphone").val());
        $.ajax({
            type: "post",
            url: "handler/SendSMS.ashx?OpareType=swqf",
            data: { tels: phones },
            dataType: 'text',
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data) {
                    var str = data.split(',');
                    $("#ydhm").html(str[0]);
                    $("#lthm").html(str[1]);
                    $("#dxhm").html(str[2]);
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 7 });
            }
        });
    });

    /****************************清空号码****************************/
    $("#btnqkhm").click(function () {
        $("#txtphone").val("");
        $("#spanPhoneLength").html("0");
        $("#ydhm").html("0");
        $("#lthm").html("0");
        $("#dxhm").html("0");
    });

    /****************************确定发送****************************/
    $("#btn_Submit").click(function () {
        var dstime = $('#txtdssj').val();
        var dxlb = $('#cmbdxlb').combobox('getValue');
        var dxlbmc = $('#cmbdxlb').combobox('getText');
        var txtqm = $.trim($("#txtQM").val());
        var msg = $.trim($("#txtMsgContent").val());
        if (dxlb.length == 0) {
            layer.msg('请选择网关类别！', { icon: 7 });
            return;
        }

        if (msg.length == 0) {
            layer.msg('短信内容不能为空！', { icon: 7 });
            return;
        }
        var fsqm = "";
        if (txtqm.length > 0) {
            fsqm = txtqm;
        }

        var istdht = $("#tdht").is(":visible");
        if (istdht == true) {
            msg = msg + "退订回T";
        }

        if (dxlbmc.indexOf("106") >= 0) {
            if (fsqm.length == 0) {
                layer.msg('签名不能为空！', { icon: 7 });
                return;
            }

            if (msg.indexOf("【") >= 0) {
                layer.msg('格式错误，只能包含一个【】签名符号！', { icon: 7 });
                return;
            }
        }

        //剩余条数判断
        sytx(dxlbmc);

        //错号排除
        chpc();

        var phones = $("#txtphone").val();

        if (phones.length == 0) {
            layer.msg('手机号不能为空！', { icon: 7 });
            return;
        }
        var sendArray = phones.split("\n");
        var sendphones = sendArray.join(',');


		alert( '发送成功' );

        $.ajax({
            type: "post",
            url: "handler/InsertSendLog.ashx",
            data: { tels: sendphones, dxid: dxlb, qm: fsqm, dxmsg: escape(clmsg(msg)), dssj: dstime },
            dataType: 'text',
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
                $("#btn_Submit").attr({ "disabled": "disabled" });
                $("#btn_Submit").text("正在发送中....");
            },
            success: function (data) {
                if (data.indexOf("发送成功") >= 0) {
                    $('#cmbdxlb').combobox('reload');
                    $("#txtphone").val("");
                    $("#lbl_CurrentSize").html("0");
                    $("#lbl_CurrentCount").html("1");
                    $("#spanPhoneLength").html("0");
                    $("#ydhm").html("0");
                    $("#lthm").html("0");
                    $("#dxhm").html("0");
                    layer.msg(data, { icon: 1 });
                } else {
                    layer.msg(data, { icon: 7 });
                }
                $("#btn_Submit").removeAttr("disabled");
                $("#btn_Submit").text("确定发送");
                return;
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg("发送异常，请重新发送", { icon: 5 });
                return;
            }
        });

    });

    /***************************改变分辨率**************************/
    $(window).resize(changeifrma);
    changeifrma();

});

function changeifrma() {
    var ggg = $(window).height();
    if (ggg > 760) {
        $("#txtphone").height(ggg - 550);
    } else {
        $("#txtphone").height("200");
    }
}

//错号排除
function chpc() {
    var phones = $("#txtphone").val();
    var re = /^1[3,4,5,6,7,8]\d{9}$/;
    var yanphone = new Array();
    var strphones = phones.split("\n");
    var check = true;
    for (var i = 0; i < strphones.length; i++) {
        var dqbb = strphones[i];
        dqbb = $.trim(strphones[i]);
        if (dqbb == "") {
            continue;
        }
        if (!re.test(dqbb)) {
            continue;
        }
        yanphone.push(dqbb);
    }

    var newmyphones = yanphone.join("\n");
    $("#txtphone").val(newmyphones);
}

//去除重复
function qchongfu() {
    var phoneArray = $("#txtphone").val().split("\n");
    phoneArray = phoneArray.del();
    var newphone = phoneArray.join('\n');
    $("#txtphone").val(newphone);
    PhoneChange();
}

function PhoneChange() {
    var phoneLength = 0;
    var phoneArray = $("#txtphone").val().split("\n");
    var re = /^1[3,4,6,5,7,8]\d{9}$/;
    $.each(phoneArray, function (index, value) {
        if (value.valueOf() != "") {
            value = $.trim(value);
            if (!re.test(value)) {
                return;
            }
            if (value.length == 11) {
                phoneLength = phoneLength + 1;
            }
        }
    });
    $("#spanPhoneLength").html(phoneLength);
}

function sytx(lbmc) {
    var start = lbmc.indexOf("剩余");
    var end = lbmc.indexOf("条");
    var curzts = lbmc.substring(start + 2, end);
    if (parseInt(curzts) ==0) {
        layer.msg('请先充值短信条数！', { icon: 7});
        return;
    }
    $.ajax({
        type: "post",
        url: "handler/mainService.ashx?type=sytx",
        data: { csyts: curzts },
        dataType: 'text',
        beforeSend: function () {
            aindex = layer.load(0, {
                shade: [0.1, '#fff']
            });
        },
        success: function (data) {
    
        },
        complete: function () {
            layer.close(aindex);
        },
        error: function (eor) {
            layer.msg("未知异常", { icon: 5 });
            return;
        }
    });
}

Array.prototype.del = function () {
    var a = {}, c = [], l = this.length;
    for (var i = 0; i < l; i++) {
        var b = this[i];
        var d = (typeof b) + b;
        if (a[d] === undefined) {
            c.push(b);
            a[d] = 1;
        }
    }
    return c;
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}


