﻿$(function () {
    $("#btnscmb").click(function () {
        baocunmb();
    });

    $("#btncydx").click(function () {
        layer.open({
            type: 2,
            title: '我的短信模板箱',
            area: ['600px', '400px'],
            fix: false, //不固定
            maxmin: false,
            content: '/sendsms/other/dxmb'
        });
    });

    $("#txtQM").keyup(function () {
        if ($("#txtQM").val().length > 0) {
            if ($("#txtQM").val().indexOf("【") != 0) {
                $("#txtQM").val("【" + $("#txtQM").val().replace("【", ""));
            }

            if ($("#txtQM").val().indexOf("】", $("#txtQM").val().length - 1) != ($("#txtQM").val().length - 1)) {
                $("#txtQM").val($("#txtQM").val().replace("】", "") + "】");
            }
        }
        ContentChange();
    });

});

function baocunmb() {
    var txtqm = $.trim($("#txtQM").val());
    var txtmsg = $.trim($("#txtMsgContent").val());

    if (txtmsg.length == 0) {
        layer.msg('内容不能为空！', { icon: 7 });
        return;
    }

    if (txtmsg.indexOf("【") > 0 || txtmsg.indexOf("】") > 0) {
        layer.msg('短信中只能包含一个【】符号，此符号代表签名，请用其它符号代替！', { icon: 7 });
        return;
    }

    var qmids = "0";
    var pjmsg = txtqm + "|" + txtmsg;
    
    $.ajax({
        type: "post",
        url: "handlerhandler/DXMBService.ashx?OpareType=addmb",
        data: { cqm: qmids, dxnrinfo: escape(pjmsg) },
        dataType: "text",
        beforeSend: function () {
            aindex = layer.load(0, {
                shade: [0.1, '#fff']
            });
        },
        success: function (data) {
            if (data == "ok") {
                layer.msg('添加成功！', { icon: 1 });
            } else if (data == "no") {
                layer.msg('添加失败！', { icon: 7 });
            } else {
                layer.msg("存在屏蔽词：[" + data + "]", { icon: 7 });
            }
        },
        complete: function () {
            layer.close(aindex);
        },
        error: function (eor) {
            layer.msg('未知异常！', { icon: 5 });
        }
    });
}

function checkkeyword() {
    var ztnr = $.trim($("#txtMsgContent").val() + $("#txtQM").val());
    if (ztnr.length > 0) {
        $.ajax({
            type: "post",
            url: "handlerhandler/SendSMS.ashx?OpareType=checkpbc",
            data: { TXTNR: escape(ztnr) },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "no") {
                    layer.msg("不包含屏蔽词！", { icon: 1 });
                } else {
                    layer.msg("存在屏蔽词：[" + data + "]", { icon: 7 });
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                return false;
            }
        });
    } else {
        layer.msg('短信内容为空！', { icon: 7 });
        return;
    }
}

function ContentChange() {
    var num = 0
    var txtqm = $.trim($("#txtQM").val());
    var tdht = $("#tdht").is(":visible");
    if (tdht == true) {
        num += 4;
    }  

    var count = $("#txtMsgContent").val().length + txtqm.length + num;
    $("#lbl_CurrentSize").html(count);
    if (count <= 70) {
        $("#lbl_CurrentCount").html("1");
    } else {
        $("#lbl_CurrentCount").html(parseInt(Math.ceil(count / 67)));
    }
}

//保存内容
function clmsg(msg) {
    msg = msg.replace("+", "$加号$");
    msg = msg.replace("!", "！");
    msg = msg.replace("=", "$等于$");
    msg = msg.replace("'", "");
    return msg;
}