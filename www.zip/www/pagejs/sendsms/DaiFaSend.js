﻿$(function () {
    var aindex;
    $('#tt').datagrid({
        url: "handler/MsgService.ashx?type=dfs",
        height: window.parent.maiHeigth+38,
        width: window.parent.maiWidth,
        nowrap: false,
        autoRowHeight: false,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50, 100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'ID', hidden: true },
                    { field: 'USERID', hidden: true },
                    { field: 'JSHM', hidden: true },
                    { field: 'LBMC', title: '网关类型', width: 80, align: 'center' },
                    { field: 'DXNR', title: '短信内容', width: 350, align: 'center' },
                    { field: 'JSHM', hidden: true },
                    { field: 'HMGS', title: '号码个数', width: 60, align: 'center' },
                    { field: 'FSTS', title: '发送条数', width: 80, align: 'center' },
                    { field: 'HMFL', title: '号码分类', width: 100, align: 'center' },
                    { field: 'FSSJ', title: '发送时间', width: 120, align: 'center' },
                    { field: 'opare', title: '操作', width: 120, align: 'center',
                        formatter: function (value, row) {
                            var e = "<a href=\"javascript:void(0);\" onclick=\"dowhms('" + row.ID + "')\">下载号码</a>&nbsp;&nbsp;";
                            e += "<a href=\"javascript:void(0);\" onclick=\"msgqx('" + row.ID + "')\">取消发送</a>";
                            return e;
                        }
                    }
				]]
    });

    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth + 38, width: window.parent.maiWidth });
    });
});

function msgqx(id) {
    if (id.length > 0) {
        var rowsr = $("#tt").datagrid("getSelected");
        if (!rowsr) {
            layer.msg('未选中取消项！', { icon: 7 });
            return;
        }
        $.ajax({
            type: "post",
            url: "handler/MsgService.ashx?type=duanxinquxiao",
            data: { qid: id },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "ok") {
                    layer.msg('取消成功！', { icon: 1 });
                    $('#tt').datagrid('reload');
                    return;
                } else {
                    layer.msg('取消失败！', { icon: 7 });
                    return;
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('发生异常！', { icon: 5 });
                return;
            }
        });
    } else {
        layer.msg('未选中要取消数据项！', { icon: 7 });
    }
}

function dowhms(id) {
    if (id) {
        $('body').append("<iframe id=\"downloadcsv\" style=\"display:none\"></iframe>");
        $('#downloadcsv').attr('src', "handler/DownService.ashx?OpareType=downHM&&MSGID=" + encodeURI(id) + "");
    }
}

 