﻿$(function () {
    var urlfzid = getQueryString("fzid");
    if (urlfzid) {
        var urlfzid = decodeURI(urlfzid);
        var re = /^1[3,4,5,7,8]\d{9}$/;
        $.ajax({
            type: "post",
            url: "handler/BookTabService.ashx?OpareType=selbyfzid",
            data: { fzid: urlfzid },
            dataType: "json",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                $("#txtphone").val(data);
                PhoneChange();
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
            }
        });
    }

    var cphone = getQueryString("phone");
    if (cphone) {
        cphone = decodeURI(cphone);
        var re = /^1[3,4,5,7,8]\d{9}$/;
        if (re.test(cphone)) {
            $("#txtphone").val(cphone);
        }
        PhoneChange();
    }

    var flhms = getQueryString("hms");
    if (flhms) {
        if (flhms != "hmfl") {
            return;
        }
        $.ajax({
            type: "post",
            url: "handler/PhoneShunt.ashx?OpareType=selhm",
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "no") {
                    layer.msg('加载失败！', { icon: 7 });
                    return;
                } else {
                    $("#txtphone").val(data);
                    PhoneChange();
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
                return;
            }
        });
    }


});