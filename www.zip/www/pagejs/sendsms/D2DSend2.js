﻿$(function () {
 $("#helpts").hover(function () {
     layer.tips('Excel中手机号码所在列！', '#hmrow', {
            tips: [1, '#78BA32']
        });
    }, function () {

    })

    //插入表示
    $("#btncr").click(function () {
        var dxnr = $.trim($("#txtMsgContent").val());
        if (dxnr.length > 0) {
            $('#txtMsgContent').insertContent("[(" + $('#insertRow').combobox('getText') + ")]");
        }
    });

    $("#txtQM").keyup(function () {
        if ($("#txtQM").val().length > 0) {
            if ($("#txtQM").val().indexOf("【") != 0) {
                $("#txtQM").val("【" + $("#txtQM").val().replace("【", ""));
            }

            if ($("#txtQM").val().indexOf("】", $("#txtQM").val().length - 1) != ($("#txtQM").val().length - 1)) {
                $("#txtQM").val($("#txtQM").val().replace("】", "") + "】");
            }
        }
        ContentChange();
    });

    $("#txtMsgContent").keyup(function () {
        ContentChange();
    });


});