﻿
$(document).ready(function () {
    $('#calendar').fullCalendar({
        editable: false,
        monthNames: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
        monthNamesShort: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
        dayNames: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
        dayNamesShort: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
        today: ["今天"],
        buttonText: {
            today: '今天/本月',
            month: '月',
            week: '周',
            day: '日'
        },
        eventClick: function (event) {

        },
        events: function (start, end, timezone, callback) {
            var viewStart = $.fullCalendar.formatDate(start, "yyyy-MM-dd");
            var viewEnd = $.fullCalendar.formatDate(end, "yyyy-MM-dd");
            $("#calendar").fullCalendar('removeEvents');

            var aindex;
            $.ajax({
                type: "post",
                url: "handler/MYTJService.ashx?OpareType=mydaytj",
                data: { KSSJ: viewStart, JSSJ: viewEnd },
                dataType: "json",
                beforeSend: function () {
                    aindex = layer.load(0, {
                        shade: [0.1, '#fff']
                    });
                },
                success: function (data) {
                    $.each(data, function (i, c) {
                        var schdata2 = { title: c.CZLX + '：' + c.CZTS + '条', start: c.CZSJ, end: c.CZSJ };
                        $('#calendar').fullCalendar('renderEvent', schdata2, true);
                    });
                },
                complete: function () {
                    layer.close(aindex);
                },
                error: function (eor) {
                    layer.msg('加载异常！', { icon: 5 });
                    layer.close(aindex);
                    return;
                }
            });
        }
    });
});
 