﻿$(function () {
    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth - 45, width: window.parent.maiWidth });
    });
 
    var urlparam;
    if (urlparam != "clear") {
        urlparam = getQueryString("cothid");
    }
    $('#tt').datagrid({
        url: "handler/MsgService.ashx?type=SMSReport",
        height: window.parent.maiHeigth - 45,
        width: window.parent.maiWidth,
        queryParams: { rowid: urlparam },
        nowrap: false,
        autoRowHeight: false,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50, 100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'ID', hidden: true },
                    { field: 'MSGTASKID', title: '任务ID', width: 110, align: 'center' },
                    { field: 'MOBILE', title: '手机号码', width: 100, align: 'center' },
                    { field: 'DXNR', title: '下发内容', width: 250, align: 'center' },
                    { field: 'FSSJ', title: '发送时间', width: 120, align: 'center' },
                    { field: 'STATUS', title: '状态', width: 80, align: 'center' },
                    { field: 'ERRORCODE', title: '返回值', width: 80, align: 'center' },
                    { field: 'RECEIVETIME', title: '回执时间', width: 120, align: 'center' }
				]]
    });

    $("#btnSearch").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        var kssj = $("#txtKSSJ").val();
        var jssj = $("#txtJSSJ").val();
        var cphone = $.trim($("#txtphone").val());
        var ctaskid = $.trim($("#txtbh").val())
        var cdxlb = $('#cmbdxlb').combobox('getValue');
        var cdxnr = $.trim($("#txtdxnr").val());
        if (kssj.length > 0 && jssj.length > 0) {
            param.push({ KSSJ: kssj });
            param.push({ JSSJ: jssj });
        }
        if (cphone.length > 0) {
            param.push({ sphone: cphone });
        }
        if (ctaskid.length > 0) {
            param.push({ curtaskid: ctaskid });
        }
        if (cdxnr.length > 0) {
            param.push({ dxnr: cdxnr });
        }
        if (cdxlb.length > 0) {
            param.push({ ztlb: cdxlb });
        }
        urlparam = "clear";
        $('#tt').datagrid('load', param);
    });


    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: parent.lbHeigth - 210, width: parent.lbWidth - 230 });
    });

    $("#btnDow").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        var kssj = $("#txtKSSJ").val();
        var jssj = $("#txtJSSJ").val();
        var cphone = $.trim($("#txtphone").val());
        var ctaskid = $.trim($("#txtbh").val())
        var cdxlb = $('#cmbdxlb').combobox('getValue');
        var cdxnr = $.trim($("#txtdxnr").val());
        if (kssj.length > 0 && jssj.length > 0) {
            param.push({ KSSJ: kssj });
            param.push({ JSSJ: jssj });
        }
        if (cphone.length > 0) {
            param.push({ sphone: cphone });
        }
        if (ctaskid.length > 0) {
            param.push({ curtaskid: ctaskid });
        }
        if (cdxnr.length > 0) {
            param.push({ dxnr: cdxnr });
        }
        if (cdxlb.length > 0) {
            param.push({ ztlb: cdxlb });
        }

        param.push({ TYPE: "状态" });
        param.push({ rowid: urlparam });
        $.ajax({
            type: "post",
            url: "handler/DownService.ashx?OpareType=downBG",
            data: param,
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                $('body').append("<iframe id=\"downloadcsv\" style=\"display:none\"></iframe>");
                $('#downloadcsv').attr('src', "handler/DownService.ashx?OpareType=downEXCEL");
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg("未知异常！", { icon: 5 });
            }
        });

    });
});

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function UrlParamDel(name) {
    var reg = new RegExp("\\\? | &" + name + "= ([^&]+)(&|&)", "i");
    return window.location.search.substr(1).replace(reg, "");
}
  