﻿$(function () {
    var aindex;
    $('#tt').datagrid({
        url: "handler/ErroCode.ashx?OpareType=select",
        height: window.parent.maiHeigth,
        width: window.parent.maiWidth,
        nowrap: false,
        autoRowHeight: false,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50, 100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'CODE', title: '代码', width: 110, align: 'center' },
                    { field: 'DESCRIBE', title: '代码说明', width: 200, align: 'center' }
                    
				]]
    });

    $("#btnSearch").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        var txtcode = $("#txtcode").val();

        if (txtcode.length > 0) {
            param.push({ ccode: txtcode });
        }
        $('#tt').datagrid('load', param);
    });


    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth, width: window.parent.maiWidth });
    });


});