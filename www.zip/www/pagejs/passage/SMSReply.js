﻿$(function () {
    var aindex;
    $('#tt').datagrid({
        url: "handler/MsgService.ashx?type=SMSReply",
        height: window.parent.maiHeigth,
        width: window.parent.maiWidth,
        nowrap: false,
        autoRowHeight: false,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: true,
        pageNumber: 1,
        resizable: true,
        pageSize: 50,
        pageList: [50,100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'MSGTASKID', title: '任务ID', width: 110, align: 'center' },
                    { field: 'MOBILE', title: '手机号码', width: 100, align: 'center' },
                    { field: 'FSSJ', title: '发送时间', width: 110, align: 'center' },
                    { field: 'REPLYTIME', title: '回复时间', width: 110, align: 'center' },
                    { field: 'DXNR', title: '发送短信内容', width: 200, align: 'center' },
                    { field: 'REPLYCONTENT', title: '回复内容', width: 200, align: 'center' },
                    { field: 'opare', title: '操作', width: 80, align: 'center',
                        formatter: function (value, row) {
                            var e = "<a href=\"javascript:void(0);\" onclick=\"hfhm('" + row.MOBILE + "')\">回复</a>&nbsp;&nbsp;&nbsp;";
                            return e;
                        }
                    }
				]]
    });

    $("#btnSearch").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        var kssj = $("#txtKSSJ").val();
        var jssj = $("#txtJSSJ").val();
        var phone = $.trim($("#txtphone").val());
        var taskid = $.trim($("#txtbh").val())
        if (kssj.length > 0) {
            param.push({ KSSJ: kssj });
            param.push({ JSSJ: jssj });
        }
        if (phone.length > 0) {
            param.push({ sphone: phone });
        }
        if (taskid.length > 0) {
            param.push({ curtaskid: taskid });
        }
        $('#tt').datagrid('load', param);
    });


    $(window).resize(function () {
        $('#tt').datagrid('resize', { height: window.parent.maiHeigth, width: window.parent.maiWidth });
    });


    $("#btnDow").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };

        var kssj = $("#txtKSSJ").val();
        var jssj = $("#txtJSSJ").val();
        var phone = $.trim($("#txtphone").val());
        var taskid = $.trim($("#txtbh").val())
        if (kssj.length > 0) {
            param.push({ KSSJ: kssj });
            param.push({ JSSJ: jssj });
        }
        if (phone.length > 0) {
            param.push({ sphone: phone });
        }
        if (taskid.length > 0) {
            param.push({ curtaskid: taskid });
        }
        param.push({ TYPE: "回复" });
        $.ajax({
            type: "post",
            url: "handler/DownService.ashx?OpareType=downBG",
            data: param,
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                $('body').append("<iframe id=\"downloadcsv\" style=\"display:none\"></iframe>");
                $('#downloadcsv').attr('src', "handler/DownService.ashx?OpareType=downEXCEL");
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg("未知异常！", { icon: 5 });
            }
        });
    });

});
function hfhm(mobile) {
    if (mobile.length > 0) {
        location.href = "../../pageinfo/sendsms/SendSMS.aspx?phone=" + encodeURI(mobile) + "";
    }
}

