﻿$(function () {
    var aindex;
    $("#btninput").click(function () {
        layer.open({
            type: 2,
            title: '导入操作',
            area: ['350px', '350px'],
            fix: false,
            maxmin: false,
            content: 'shunt_info.php'
        });
    });

    $("#btnyhm").click(function () {
        var yhm = $("#txtyhm").val();
        if (yhm.length > 0) {
            $.ajax({
                type: "post",
                url: "handler/PhoneShunt.ashx?OpareType=clhms",
                data: { chms: yhm },
                dataType: "text",
                beforeSend: function () {
                    aindex = layer.load(0, {
                        shade: [0.1, '#fff']
                    });
                },
                success: function (data) {
                    if (data) {
                        var arr = data.split("$$");
                        var cydhm = arr[0];
                        var clthm = arr[1];
                        var cdxhm = arr[2];
                        var yhmnum = yhm.split("\n");
                        var ydnum = cydhm.split("\n");
                        var ltnum = clthm.split("\n");
                        var dxnum = cdxhm.split("\n");
                        $("#spyhm").html(yhmnum.length);
                        $("#txtydhm").val(cydhm);
                        $("#txtdxhm").val(clthm);
                        $("#txtlthm").val(cdxhm);
                        $("#spydhm").html(ydnum.length);
                        $("#spdxhm").html(ltnum.length);
                        $("#splthm").html(dxnum.length);
                    }
                },
                complete: function () {
                    layer.close(aindex);
                },
                error: function (eor) {
                    layer.msg('未知异常！', { icon: 5 });
                    return;
                }
            });
        }
    });

    $("#btnydhm").click(function () {
        var ydhm = $("#txtydhm").val();
        if (ydhm.length > 0) {
            var newydhm = ydhm;
            $.ajax({
                type: "post",
                url: "handler/PhoneShunt.ashx?OpareType=savehm",
                data: { clhm: newydhm },
                dataType: "text",
                beforeSend: function () {
                    aindex = layer.load(0, {
                        shade: [0.1, '#fff']
                    });
                },
                success: function (data) {
                    location.href = "pageinfo/sendsms/SendSMS.aspx?hms=hmfl";
                },
                complete: function () {
                    layer.close(aindex);
                },
                error: function (eor) {
                    layer.msg('未知异常！', { icon: 5 });
                    return;
                }
            });
        }
    });

    $("#btnlthm").click(function () {
        var lthm = $("#txtlthm").val();
        if (lthm.length > 0) {
            var newydhm = lthm;
            $.ajax({
                type: "post",
                url: "handler/PhoneShunt.ashx?OpareType=savehm",
                data: { clhm: newydhm },
                dataType: "text",
                beforeSend: function () {
                    aindex = layer.load(0, {
                        shade: [0.1, '#fff']
                    });
                },
                success: function (data) {
                    location.href = "pageinfo/sendsms/SendSMS.aspx?hms=hmfl";
                },
                complete: function () {
                    layer.close(aindex);
                },
                error: function (eor) {
                    layer.msg('未知异常！', { icon: 5 });
                    return;
                }
            });
        }
    });

    $("#btndxhm").click(function () {
        var dxhm = $("#txtdxhm").val();
        if (dxhm.length > 0) {
            var newydhm = dxhm;
            $.ajax({
                type: "post",
                url: "handler/PhoneShunt.ashx?OpareType=savehm",
                data: { clhm: newydhm },
                dataType: "text",
                beforeSend: function () {
                    aindex = layer.load(0, {
                        shade: [0.1, '#fff']
                    });
                },
                success: function (data) {
                    location.href = "pageinfo/sendsms/SendSMS.aspx?hms=hmfl";
                },
                complete: function () {
                    layer.close(aindex);
                },
                error: function (eor) {
                    layer.msg('未知异常！', { icon: 5 });
                    return;
                }
            });
        }
    });

    $("#btnclear").click(function () {
        $("#txtyhm").val("");
        $("#txtydhm").val("");
        $("#txtdxhm").val("");
        $("#txtlthm").val("");
        $("#spyhm").html("0");
        $("#spydhm").html("0");
        $("#spdxhm").html("0");
        $("#splthm").html("0");
    });
});

 