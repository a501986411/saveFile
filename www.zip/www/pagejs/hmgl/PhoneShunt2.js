﻿$(function () {
    $list = $('#fileList');
    var uploader = WebUploader.create({
        auto: false,
        swf: 'lib/webuploader/Uploader.swf',
        server: 'handler/UploadService.php?OpareType=uptxt',
        pick: {
            'id': '#picker',
            'multiple': false
        },
        accept: {
            title: 'txt',
            extensions: 'txt,xls,xlsx,csv'
        },

        duplicate: true,
        fileNumLimit: 1,
        fileSizeLimit: 50 * 1024 * 1024  //4M

    });

    // 当有文件添加进来的时候
    uploader.on('fileQueued', function (file) {
        var filshtml = $('<div id="' + file.id + '" class="file-item thumbnail"></div>');
        $list.html(filshtml);

        var name = file.name;
        var size = file.size;
        var ext = name.substr(name.indexOf(".") + 1); //后缀

        if (size > 100 * 1024 * 1024) {
            layer.msg('文件大小不能超过100M！', { icon: 7 });
            return;
        }
        if (ext == 'xls' || ext == 'xlsx' || ext == 'csv') {
            $("#upname").html(file.name);
        } else {
            layer.msg('文件仅限xls,xlsx,csv文本格式！', { icon: 7 });
            return;
        }
    });

    // 文件上传过程中创建进度条实时显示。
    uploader.on('uploadProgress', function (file, percentage) {
        $(".ws-progress").css("display", "inline-block");
        $(".ws-progress").find(".bar").find("span").css("width", percentage * 100 + "%");
        if (percentage == 1) {
            $(".ws-progress").find(".text").text(parseInt(percentage * 100) + "%,数据解析中...");
            $(".bar").children('i').addClass('hidden')
        } else {
            $(".ws-progress").find(".text").text(parseInt(percentage * 100) + "%");
        }

    });

    // 文件上传过程中创建进度条实时显示。
    uploader.on('uploadProgress', function (file, percentage) {
        $(".ws-progress").css("display", "block");
        if (percentage == 1) {
            $(".ws-progress").find(".text").text(parseInt(percentage * 100) + "%");
            $(".bar").children('i').addClass('hidden')
        } else {
            $(".ws-progress").find(".text").text(parseInt(percentage * 100) + "%");
        }
        $(".ws-progress").find(".bar").find("span").css("width", percentage * 100 + "%");
    });

    uploader.on('uploadError', function (file) {
        layer.msg('上传失败！', { icon: 5 });
    });

    uploader.on('uploadComplete', function (file) {
        $(".ws-progress").css("display", "none");
    });

    // 文件上传成功
    uploader.on('uploadSuccess', function (file, response) {
        if (response) {
            var phoneArray = response.result.split(",");
            var newphone = phoneArray.join('\n');
            parent.$("#txtyhm").val('');
            parent.$("#txtyhm").val(newphone);
            layer.msg('导入完成', { icon: 1 });
            parent.$("#spyhm").html(response.count);
            var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
            parent.layer.close(index); //再执行关闭   
        }
    });

    uploader.on('uploadAccept', function (file, response) {
        layer.msg('解析[' + file.name + ']完成！', { icon: 1 });
    });

    $("#picker").click(function () {
        if (!WebUploader.Uploader.support()) {
            var error = "上传控件不支持您的浏览器！请尝试升级flash版本或者使用Chrome引擎的浏览器。<a target='_blank' href='http://se.360.cn'>下载页面</a>";
            layer.msg(error, { icon: 5 });
            return;
        }
        var id = $list.find("div").attr("id");
        if (undefined != id) {
            uploader.removeFile(uploader.getFile(id));
        }
    });


    $("#btnshuntok").click(function () {
        var id = $list.find("div").attr("id");
        uploader.upload(uploader.getFile(id));
    });

});


