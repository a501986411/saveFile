﻿$(function () {
    var aindex;
    selectTree();
    seltable();
    layer.tips('双击”菜单分组名称，查询对应分组内容；点击“分组名”鼠标右键操作！', '#treeview', {
        tips: [1, '#78BA32'], time: 4000
    });

    $("#btnadd").click(function () {
        var selnode = $('#treeview').tree('getSelected');
        if (selnode) {
            layer.open({
                type: 2,
                title: '新建分组',
                area: ['250px', '140px'],
                fix: false,
                maxmin: false,
                content: '/tree/add/'
            });
        } else {
            layer.msg('选中要建立的分组！', { icon: 7 });
            return;
        }
    });

    $("#btnup").click(function () {
        var selnode = $('#treeview').tree('getSelected');
        if (selnode) {
            if (selnode.text != "我的分组") {
                layer.open({
                    type: 2,
                    title: '修改分组名',
                    area: ['250px', '140px'],
                    fix: false,
                    maxmin: false,
                    content: '/tree/update/'
                });
            }
        } else {
            layer.msg('选中要修改的分组！', { icon: 7 });
            return;
        }
    });

    $("#btndel").click(function () {
        var n = $('#treeview').tree('getSelected');
        if (n) {
            if (n.text != "我的分组") {
                var child = $('#treeview').tree('getChildren', n.target);
                if (child.length > 0) {
                    layer.confirm('删除项目包含子节点，是否全部删除？', {
                        btn: ['确定删除', '取消'] //按钮
                    }, function (index) {
                        $.ajax({
                            type: "post",
                            url: "handler/BookService.ashx?OpareType=delTree",
                            data: { treeid: n.id },
                            dataType: "text",
                            beforeSend: function () {
                                aindex = layer.load(0, {
                                    shade: [0.1, '#fff']
                                });
                            },
                            success: function (data) {
                                if (data == "ok") {
                                    $('#treeview').tree('remove', n.target);
                                    layer.msg('删除成功！', { icon: 1 });
                                    $('#tt').datagrid('loadData', { total: 0, rows: [] });
                                } else {
                                    layer.msg('删除失败！', { icon: 7 });
                                }
                            },
                            complete: function () {
                                layer.close(aindex);
                            },
                            error: function (eor) {
                                layer.msg('未知异常！', { icon: 5 });
                                return;
                            }
                        });
                    }, function () {

                    });
                } else {
                    $.ajax({
                        type: "post",
                        url: "handler/BookService.ashx?OpareType=delTree",
                        data: { treeid: n.id },
                        dataType: "text",
                        beforeSend: function () {
                            aindex = layer.load(0, {
                                shade: [0.1, '#fff']
                            });
                        },
                        success: function (data) {
                            if (data == "ok") {
                                $('#treeview').tree('remove', n.target);
                                $('#tt').datagrid('loadData', { total: 0, rows: [] });
                            } else {
                                layer.msg('删除失败！', { icon: 7 });
                            }
                        },
                        complete: function () {
                            layer.close(aindex);
                        },
                        error: function (eor) {
                            layer.msg('未知异常！', { icon: 5 });
                            return;
                        }
                    });
                }
            }
        }
        else {
            layer.msg('选中要删除的子菜单！', { icon: 7 });
            return;
        }
    });

    $("#btnfzsend").click(function () {
        var n = $('#treeview').tree('getSelected');
        if (n) {
            window.location.href = "pageinfo/sendsms/SendSMS.aspx?fzid=" + encodeURI(n.id) + "";
        }
    });

    $("#btnAdd").click(function () {
        var name = $.trim($("#txtname").val());
        var phone = $.trim($("#txtphone").val());
        if (name.length == 0) {
            layer.tips('请输入姓名', '#txtname');
            return;
        }

        if (phone.length == 0) {
            layer.tips('请输入手机号码', '#txtphone');
            return;
        }
        var re = /^1[3,4,5,6,7,8]\d{9}$/;
        if (!re.test(phone)) {
            layer.tips('号码格式错误', '#txtphone');
            return;
        }

        var n = $('#treeview').tree('getSelected');
        var cfzid = "";
        if (n) {
            cfzid = n.id;
        } else {
            layer.msg('未选中分组！', { icon: 7 });
            return;
        }
        $.ajax({
            type: "post",
            url: "handler/BookTabService.ashx?OpareType=addtable",
            data: { telname: name, telphone: phone, fzid: cfzid },
            dataType: "text",
            beforeSend: function () {
                aindex = layer.load(0, {
                    shade: [0.1, '#fff']
                });
            },
            success: function (data) {
                if (data == "no") {
                    layer.msg('添加失败！', { icon: 7 });
                    return;
                } else {
                    $('#tt').datagrid('insertRow', {
                        index: 0,
                        row: { ID: data, FZMC: n.text, NAME: name, PHONE: phone }
                    });
                }
            },
            complete: function () {
                layer.close(aindex);
            },
            error: function (eor) {
                layer.msg('未知异常！', { icon: 5 });
                return;
            }
        });
    });

    $("#btnseltab").click(function () {
        var param = {};
        param.push = function (o) {
            if (typeof (o) == 'object') for (var p in o) this[p] = o[p];
        };
        param.push({ name: $("#txtname").val() });
        param.push({ phone: $('#txtphone').val() });
        var n = $('#treeview').tree('getSelected');
        if (n) {
            param.push({ fzid: n.id });
        }
        $('#tt').datagrid('load', param);
    });

    $("#btnDR").click(function () {
        var selnode = $('#treeview').tree('getSelected');
        if (selnode) {
            layer.open({
                type: 2,
                title: '导入联系人',
                area: ['600px', '400px'],
                fix: false,
                maxmin: false,
                content: '/phones/add/'
            });
        } else {
            layer.msg('未选择要导入的分组！', { icon: 7 });
            return;
        }
    });

    //批量删除
    $("#btnDel").click(function () {
        delTable();
    });
    $(window).resize(changeifrma);
    changeifrma();

});

function selectTree() {
    $('#treeview').tree({
        checkbox: false,
        id: "ID",
        text: "FZMC",
        checked: true,
        url: "handler/BookService.ashx?OpareType=seltree",
        animate: false,
        onDblClick: function (node) {
            if (node) {
                $('#tt').datagrid('load', { fzid: node.id });
            }
        },
        onLoadSuccess: function (row, data) {
            $('#treeview').tree("collapseAll");
            var curnode = $('#treeview').tree("find", data[0].id);
            $('#treeview').tree("expand", curnode.target);
        },
        onContextMenu: function (e, node) {
            if (node.text.length > 0) {
                e.preventDefault();
                $('#rightMenu').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            }
        }
    });
}

function seltable() {
    $('#tt').datagrid({
        url: "handler/BookTabService.ashx?OpareType=seltable",
        height: window.parent.maiHeigth,
        width: window.parent.maiWidth - 200,
        nowrap: true,
        autoRowHeight: true,
        striped: true,
        collapsible: true,
        pagination: true,
        rownumbers: false,
        fitColumns: true,
        singleSelect: false,
        pageNumber: 1,
        resizable: false,
        pageSize: 50,
        pageList: [50, 100, 200, 500],
        loadMsg: "正在努力加载，请稍等....",
        columns: [[
                    { field: 'ck', checkbox: 'true', width: 50 },
                    { field: 'ID', hidden: true },
                    { field: 'FZMC', title: '所属分组', width: 100, align: 'center' },
                    { field: 'NAME', title: '联系人', width: 100, align: 'center' },
					{ field: 'PHONE', title: '手机号', width: 100, align: 'center' },
                    { field: 'BZ', title: '备注', width: 200, align: 'center' },
                    { field: 'opare', title: '操作', width: 80, align: 'center',
                        formatter: function (value, row, index) {
                            var e = '<div id="div1">' +
                                        '<a href="javascript:void(0);" id="tabuphm" onclick=\"update(' + row.ID + ')\">修改</a> &nbsp;&nbsp;' +
                                        '<a href="javascript:void(0);" id="sendhm" onclick=\"send(' + row.PHONE + ')\" style="color:Red;" >发送短信</a>' +
                                    '</div>';
                            return e;
                        }
                    }
				]]
    });
}

function changeifrma() {
    var tabheigth = window.parent.maiHeigth;
    if (tabheigth < 300) {
        tabheigth = 500;
    }
    $('#tt').datagrid('resize', { height: tabheigth, width: window.parent.maiWidth - 200 });
    if (window.parent.maiHeigth < 400) {
        $('#layout').css("height", 500);
    }
    $('#layout').css("height", window.parent.maiHeigth);
    $('#layout').layout();
}

function update(rowid) {
    var selrows = $('#tt').datagrid('getSelections');
    $('#tt').datagrid('unselectAll');
    var row;
    $.each(selrows, function () {
        if (rowid == this.ID) {
            row = this;
        }
    });
    if (rowid && row) {
        layer.open({
            type: 2,
            title: '修改联系人',
            area: ['300px', '290px'],
            fix: false,
            maxmin: false,
            content: '/phones/update/'
        });
    } else {
        layer.tips('未选中修改数据项！', '#tabuphm');
        return;
    }
}

function delTable() {
    var selids = "";
    var rowsr = $("#tt").datagrid("getSelections");
    if (!rowsr) {
        layer.msg("未选中数据项！", { icon: 7 });
        return;
    }
    $.each(rowsr, function () {
        selids += this.ID + ",";
    });
    if (selids.length == 0) {
        layer.msg("未选中数据项！", { icon: 7 });
        return;
    }

    $.ajax({
        type: "post",
        url: "handler/BookTabService.ashx?OpareType=deltable",
        data: { telid: selids },
        dataType: "text",
        beforeSend: function () {
            aindex = layer.load(0, {
                shade: [0.1, '#fff']
            });
        },
        success: function (data) {
            if (data == "ok") {
                $('#tt').datagrid('reload');
                layer.msg("删除成功！", { icon: 1 });
            } else {
                layer.msg("删除失败！", { icon: 7 });
            }
        },
        complete: function () {
            layer.close(aindex);
        },
        error: function (eor) {
            layer.msg("未知异常！", { icon: 5 });
        }
    });
}

function send(telphone) {
    var re = /^1[3,4,5,7,8]\d{9}$/;
    if (re.test(telphone)) {
        window.location.href = "pageinfo/sendsms/SendSMS.aspx?phone=" + encodeURI(telphone) + "";
    } else {
        layer.tips('号码格式错误！', '#sendhm');
    }
}