<?php
	
// handler/UploadService.ashx?OpareType=uptxt
