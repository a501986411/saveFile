<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/4/4
 * Time: 22:25
 */
require_once '../common.php';
$userId = empty($_POST['userId']) ? 100 : $_POST['userId'];
echo getLog($userId);
function getLog($userId)
{
    $sql = 'select * from send_msg_log where user_id='.$userId;
    $db = db();
    $rs = $db->query($sql);
    $rows = $rs->fetchAll();
    foreach ($rows as $k=>&$v){
        $v['ID'] = $v['id'];
        $v['TASKID'] = $v['task_id'];
        $v['USERID'] = $v['user_id'];
        $v['LBMC'] = '会员精准';
        $v['DXNR'] = $v['content'];
        $v['HMGS'] = $v['tel_num'];
        $v['HMFL'] = $v['tel_type'];
        $v['FSTS'] = $v['send_num'];
        $v['FSZT'] = $v['send_status'];
        $v['FSIP'] = $v['send_ip'];
        $v['FSSJ'] = $v['send_time'];
    }
    return json_encode($rows);
}