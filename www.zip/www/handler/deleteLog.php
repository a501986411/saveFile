<?php
	/**
	 *
	 * Created by PhpStorm.
	 * User: knight
	 * Date: 2017/4/5
	 * Time: 17:10
	 */
require_once '../common.php';
$id = intval($_POST['id']);
echo deleteLog($id);
function deleteLog($id)
{
	$sql = 'delete from send_msg_log where id='.$id;
	$db = db();
	if($db->exec($sql)===false){
		return false;
	}
	return true;
}