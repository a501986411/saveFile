<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="lib/bootstrap/css/theme.css" rel="stylesheet" type="text/css" />
    <link href="css/button.css" rel="stylesheet" type="text/css" />
    <link href="lib/webuploader/webuploader.css" rel="stylesheet" type="text/css" />
    <script src="lib/jquery-1.8.1.min.js" type="text/javascript"></script>
    <script src="lib/webuploader/webuploader.js" type="text/javascript"></script>
    <script src="lib/layer/layer.js" type="text/javascript"></script>
    <script src="pagejs/hmgl/PhoneShunt2.js" type="text/javascript"></script>
    <script src="public/ahrecl.js" type="text/javascript"></script>
    <style>
        td
        {
            height: 35px;
        }
    </style>
    
</head>
<body>
    <div style="margin-left: 10px; margin-top: 5px;">
        <div>
            <table width="100%" border="0">
                <tr>
                    <td colspan="3">
                        <h4>
                            导入手机号码</h4>
                    </td>
                </tr>
                <tr>
                    <td>
                        第一步：
                    </td>
                    <td colspan="2">
                        请先<a href="javascript:void(0);" onclick="lianjie('bar')">下载模板</a>,按说明填写手机号码后上传
                    </td>
                </tr>
                <tr>
                    <td>
                        第二步：
                    </td>
                    <td>
                        导入文件
                    </td>
                    <td align="left">
                        <div class="btns">
                            <div id="picker">
                                选择EXCEL</div>
                            <div id="fileList" class="uploader-list">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" align="left">
                        *文件: < 100M<br />
                        *支持：<span style="color: #0088cc; font-weight: bold;">txt、csv/xls/xlsx</span> 文档
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <div id="upname" style="color: #0088cc; font-weight: bold;">
                            未选择文件
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <div class="ws-progress" style="display: none;">
                            <div class="bar pull-left">
                                <span style="width: 0px;"></span><i class="iconfont"></i></div>
                            <div class="text pull-left">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" align="center">
                        <a href="javascript:void(0)" class=" btn" id="btnshuntok">确定上传</a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
